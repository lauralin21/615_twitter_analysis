library(shiny)
library(ggplot2)
library(rsconnect)
xlist = colnames(iris)
ylist = colnames(iris)
ui <- shinyUI(fluidPage(
  titlePanel("Twitter Analysis Project on Nike and Adidas"),
  navbarPage(title = "Content",
             
             #introduction
             tabPanel("Introduction",
                      h1("Introcution on Twitter Analysis Project",align = "center"),
                      br(),
                      h3("Laura Lin     2017/12/18",align = "center"),
                      br(),
                      br(),
                      br(),
                      br(),
                      h4("Nike and Adidas are two popular brands producing sport goods. 
                        Therefore, it may be interesting to see how people talk about these two brands in different ways."),
                      br(),
                      h4("In this project, I will be analyzing the tweets using nike/adidas as hashtags. I will first compare their content. 
                        And I will see if the content of tweets related to a certain brand will change as time goes.")
             ),
             
             #word frequency
             tabPanel("Word Frequency",
                      h1("Visualization of Top 30 Most Frequent Words",align = "center"),
                      br(),
                      splitLayout(img(src = "nike_freq.jpg",height = 400),
                                  img(src = "ad_freq.jpg",height = 400)
                      ),
                      br(),
                      p("Here we can see most of the words are the names of products.
                        They are mostly about the shoes and sport shirts of these two brands, 
                        which match the types of their popular products."),
                      
                      p("An unexpected dicovery is that nike is the 20th most frequent word appearing in adidas-related tweets.
                        However, adidas is only the 57th most frequent word appearing in nike-related tweets. 
                        This is interesting because it shows that people like mentioning nike when they tweet about adidas but not exactly the opposite. 
                        It means that they like to compare adidas with nike when they talk about adidas but won't really think about adidas while talking about nike. 
                        This could be an implication that nike is more of a representative brand of sport goods than adidas, which should be a useful discovery for both two companies.")
             ),
             
             #common words
             tabPanel("Common Words",
                      h1("Analysis of Common Words",align = "center"),
                      br(),
                      img(src = "common_word.png",style="display: block; margin-left: auto; margin-right: auto;"),
                      br(),
                      p("We can see that the words new,now,release and ebay are all in the list of top 30 most frequent words of the tweets using nike and adidas hashtags. 
                        From the first three words, we can get the information that people like tweeting on product release of nike and adidas. 
                        Generally speaking, the proportion of these three words are higher for nike than adidas."),

                      p("In addition to this,ebay is the 13th most frequent word appearing in nike-related tweets and is the 23th most frequent word appearing in adidas-related tweets. 
                        These are valuable information. From this we may guess that ebay is a commonly used platform for selling and buying nike and adidas products. 
                        The usage of it should be popular enough so people tweet a lot about it.")
                      ),
             
             #text focus
             tabPanel("Text Focus",
                      h1("Difference of Text Focus",align = "center"),
                      br(),
                      p("After looking for the meaning of each of the top 30 most frequent words,I manually categorize the words into five categories: clothes,shoe,product release,third-party platform and other."),
                      p("The shirt category contains words about the styles of clothes,for example uniforms and jersey. The shoe category contains words of the names of shoe such as air,boost and tint. The product release category contains words like new and release. The third-party platform category contains names of the third-party like footlocker and ebay. The last category-other contains more general words such as online, size and stores."),
                      img(src="text_focus.jpg",height = 550,style="display: block; margin-left: auto; margin-right: auto;"),
                      
                      p("As we can see, the distributions look very different for the two brands. For tweets on products, adidas-related tweets focus much more on shoes than clothes while the distributions of shoe and shirt look pretty even for Nike. Therefore, we may say that people who tweet about adidas are muchn more interetsed in discussing its shoes than its clothes. And the interest on clothes and shoes of people who tweet about nike are pretty much the same. From this we can find out which kind of products of these two brands is more popular in people's discussion."),
                      p("Also we can see that people who tweet about adidas care more about its product release than people who tweet about nike. From this we may infer that the product release of adidas attract more attention than nike's."),
                      p("The proportion of tweets of nike about third-party platform is slightly higher than adidas'. This could be because the transactions of nike products on third-party platform are more common than adidas's.")
             ),
             
             #words on shoes
             tabPanel("Words about Shoes",
                      h1("Diffrent Frequent Words about Shoes",align = "center"),
                      br(),
                      p("Since we can see that words related to shoes appear most frequently in tweets under both nike and adidas, we will take out the words about shoes in the top 30 most frequent words to see which kind of things people like talking about on their shoes."),
                      splitLayout(img(src = "nike_shoe.jpg",height = 400),
                                  img(src = "ad_shoe.jpg",height = 400)
                      ),
                      br(),
                      p("There are both similarity and difference between this two graphs. Similarity are that both graph contain names of the shoes like 'air'','jordan' for nike and 'yeezy','splyr' for adidas. Difference is that there are many words about color in the adidas graphs that the nike graph doesn't contain. Its shows that when people tweet about adidas' shoes, they not only use the names of the shoes to refer to them but also use a certain color to describe a set of shoes."),
                      p("The way that people mention the product may not seem important. But it actually reflects the expressions of products in their minds. For example, when people directly use the name of shoes to point to their interested shoes, they want to talk about that specific style, which corresponds to a specific function, apperance and even price. On the other hand, if people use color names to refer to shoes, it means that they just want to talk about shoes in that color without anything specific on their functions or other perspectives.")
             ),
             
             #map distribution
             tabPanel("Map Distribution",
                      h1("Map Distribution of Tweets",align = "center"),
                      br(),
                      splitLayout(img(src = "nike_map.jpg",height = 400),
                                  img(src = "adidas_map.jpg",height = 400)
                      ),
                      p("The map distribution of tweets related to nike/adidas are similar. Most of the tweets are posted by people in North America, which is reasonable because both nike and adidas are American brands. The second largest group locates on Western Europe, which also makes sense because nike and adidas are popular in Europe too. The rest are posted by people in Asia, Africa and South America, which are located pretty disperse without too much pattern.")
             ),
             
             #change of frequency
             tabPanel("Change of Word Frequency",
                      h1("How Word Frequency of Certain Words Changes as Time Changes",align = "center"),
                      br(),
                      p("Theoretically speaking, the attention on new product release will become higher as the time approches the release date. Here I would like to see if we can infer on any future release based on the the change of peoples' interest in December in 2017 by visualizing the change of word frequency of product release related words."),
                      img(src="time_change.jpg",height = 550,style="display: block; margin-left: auto; margin-right: auto;"),
                      p("As we expect, the frequency of words--'new', 'now' and 'release' become much higher in the late December, from which we can assume that the release will be in the beginning of 2018. Nike did a successful advertising because people are talking about the release. This method could be used by companies to detect the change of people's interest on their new product. If there is not much change as the release date approches, the reason could be either the company doesn't do enough advertising so people don't know about it or the advertising is done so early compared with the release date that people's interest already faded.")
             )
             
)# end of navbar
)# end fluid page
)# end shiny UI


server <- shinyServer(function(input, output) { }) #end of shinyserver


# Run the application 
shinyApp(ui = ui, server = server)

